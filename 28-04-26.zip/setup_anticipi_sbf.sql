-- ═══════════════════════════════════════════════════════════════════════════
-- SETUP ANTICIPI SBF — modulo Anticipo Fatture
-- Phoenix Fuel S.r.l. — 28/04/2026
--
-- Architettura:
--   1. Estensione banche_affidamenti  → 3 nuovi campi per fidi anticipi
--   2. anticipi_sbf_regole            → regole anticipo per coppia banca+cliente
--   3. anticipi_sbf_presentazioni     → la richiesta complessiva alla banca
--   4. anticipi_sbf_fatture           → singole fatture dentro la presentazione
--   5. anticipi_sbf_accrediti         → multi-accredito banca (49k oggi + 14k dom)
--
-- Regole costituzionali rispettate:
--   - DISABLE ROW LEVEL SECURITY (regola #26)
--   - banche dinamiche da banche_affidamenti, niente hardcoding
-- ═══════════════════════════════════════════════════════════════════════════

-- ─── 1. ESTENSIONE banche_affidamenti ─────────────────────────────────────
-- Aggiungo 3 campi che servono SOLO ai fidi tipo='sbf' o 'anticipo_fatture'.
-- Restano NULL per fidi cassa/fideiussione/etc.
ALTER TABLE banche_affidamenti
  ADD COLUMN IF NOT EXISTS pct_anticipo_default NUMERIC(5,2) DEFAULT NULL;
ALTER TABLE banche_affidamenti
  ADD COLUMN IF NOT EXISTS base_calcolo_default TEXT DEFAULT NULL
    CHECK (base_calcolo_default IS NULL OR base_calcolo_default IN ('imponibile','totale'));
ALTER TABLE banche_affidamenti
  ADD COLUMN IF NOT EXISTS giorni_estinzione_anticipo INTEGER DEFAULT 30;

COMMENT ON COLUMN banche_affidamenti.pct_anticipo_default IS
  'Solo per tipo SBF/anticipo_fatture: % di anticipo proposta di default (es. 100, 80, 82)';
COMMENT ON COLUMN banche_affidamenti.base_calcolo_default IS
  'Base di calcolo della percentuale: imponibile (ENI tipico) o totale (BCC tipico)';
COMMENT ON COLUMN banche_affidamenti.giorni_estinzione_anticipo IS
  'Giorni di default proposti per scadenza anticipo banca (es. 30, 60, 90)';


-- ─── 2. anticipi_sbf_regole ──────────────────────────────────────────────
-- Override del default banca per cliente specifico.
-- cliente_id NULL = regola DEFAULT della banca (in genere copia del default da affidamento)
CREATE TABLE IF NOT EXISTS anticipi_sbf_regole (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  affidamento_id UUID NOT NULL REFERENCES banche_affidamenti(id) ON DELETE CASCADE,
  cliente_id UUID REFERENCES clienti(id) ON DELETE CASCADE,
  percentuale_anticipo NUMERIC(5,2),
  base_calcolo TEXT CHECK (base_calcolo IS NULL OR base_calcolo IN ('imponibile','totale')),
  massimale_cliente NUMERIC(14,2),
  stato TEXT NOT NULL DEFAULT 'attiva' CHECK (stato IN ('attiva','esclusa')),
  note TEXT,
  inserito_at TIMESTAMP DEFAULT NOW(),
  modificato_at TIMESTAMP DEFAULT NOW(),
  UNIQUE (affidamento_id, cliente_id)
);

CREATE INDEX IF NOT EXISTS idx_regole_affidamento ON anticipi_sbf_regole(affidamento_id);
CREATE INDEX IF NOT EXISTS idx_regole_cliente ON anticipi_sbf_regole(cliente_id);

ALTER TABLE anticipi_sbf_regole DISABLE ROW LEVEL SECURITY;


-- ─── 3. anticipi_sbf_presentazioni ────────────────────────────────────────
-- La "presentazione" alla banca: 1 record = 1 distinta presentata
CREATE TABLE IF NOT EXISTS anticipi_sbf_presentazioni (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  affidamento_id UUID NOT NULL REFERENCES banche_affidamenti(id) ON DELETE RESTRICT,
  data_presentazione DATE NOT NULL,
  numero_protocollo TEXT,
  stato TEXT NOT NULL DEFAULT 'in_delibera' CHECK (stato IN (
    'in_delibera',          -- presentata, banca non ha ancora deciso
    'anticipata_parziale',  -- accreditato qualcosa ma < richiesto
    'anticipata',           -- accreditato tutto il richiesto
    'estinta',              -- tutte fatture incassate dai clienti
    'rifiutata'             -- banca ha rifiutato (le fatture tornano disponibili)
  )),
  importo_richiesto NUMERIC(14,2) NOT NULL DEFAULT 0,
  importo_anticipato_totale NUMERIC(14,2) NOT NULL DEFAULT 0,
  note TEXT,
  inserito_at TIMESTAMP DEFAULT NOW(),
  modificato_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pres_affidamento ON anticipi_sbf_presentazioni(affidamento_id);
CREATE INDEX IF NOT EXISTS idx_pres_data ON anticipi_sbf_presentazioni(data_presentazione DESC);
CREATE INDEX IF NOT EXISTS idx_pres_stato ON anticipi_sbf_presentazioni(stato);

ALTER TABLE anticipi_sbf_presentazioni DISABLE ROW LEVEL SECURITY;


-- ─── 4. anticipi_sbf_fatture ──────────────────────────────────────────────
-- Singole fatture dentro una presentazione.
-- fattura_id può essere NULL (fattura inserita manualmente, non da Danea).
-- scadenza_banca è INDIPENDENTE da scadenza_cliente (decisa da operatore).
CREATE TABLE IF NOT EXISTS anticipi_sbf_fatture (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  presentazione_id UUID NOT NULL REFERENCES anticipi_sbf_presentazioni(id) ON DELETE CASCADE,
  fattura_id UUID REFERENCES fatture_emesse(id) ON DELETE SET NULL,
  numero_fattura TEXT NOT NULL,
  data_emissione DATE,
  cliente_id UUID REFERENCES clienti(id),
  cliente_nome TEXT,
  totale_fattura NUMERIC(14,2) NOT NULL DEFAULT 0,
  imponibile NUMERIC(14,2) NOT NULL DEFAULT 0,
  scadenza_cliente DATE,
  scadenza_banca DATE NOT NULL,
  percentuale_applicata NUMERIC(5,2),
  base_calcolo_applicata TEXT CHECK (base_calcolo_applicata IS NULL OR base_calcolo_applicata IN ('imponibile','totale')),
  importo_anticipato_calcolato NUMERIC(14,2) NOT NULL DEFAULT 0,
  importo_estinto NUMERIC(14,2) NOT NULL DEFAULT 0,
  data_incasso DATE,
  stato TEXT NOT NULL DEFAULT 'presentata' CHECK (stato IN (
    'presentata','anticipata','estinta','insoluta','esclusa'
  )),
  note TEXT,
  inserito_at TIMESTAMP DEFAULT NOW(),
  modificato_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_anticipi_ft_pres ON anticipi_sbf_fatture(presentazione_id);
CREATE INDEX IF NOT EXISTS idx_anticipi_ft_fattura ON anticipi_sbf_fatture(fattura_id);
CREATE INDEX IF NOT EXISTS idx_anticipi_ft_cliente ON anticipi_sbf_fatture(cliente_id);
CREATE INDEX IF NOT EXISTS idx_anticipi_ft_scadenza_banca ON anticipi_sbf_fatture(scadenza_banca);
CREATE INDEX IF NOT EXISTS idx_anticipi_ft_stato ON anticipi_sbf_fatture(stato);

-- Vincolo: 1 fattura attiva su 1 sola banca alla volta.
-- Se rifiutata o esclusa, torna disponibile per altre presentazioni.
CREATE UNIQUE INDEX IF NOT EXISTS idx_anticipi_ft_univoca
  ON anticipi_sbf_fatture(fattura_id)
  WHERE fattura_id IS NOT NULL AND stato NOT IN ('esclusa');

ALTER TABLE anticipi_sbf_fatture DISABLE ROW LEVEL SECURITY;


-- ─── 5. anticipi_sbf_accrediti ────────────────────────────────────────────
-- Multi-accredito banca: stessa presentazione può ricevere accrediti su date diverse.
-- Esempio reale: presentazione 23/04 → accredito 49.759 il 23/04 + 14.448 il 24/04
CREATE TABLE IF NOT EXISTS anticipi_sbf_accrediti (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  presentazione_id UUID NOT NULL REFERENCES anticipi_sbf_presentazioni(id) ON DELETE CASCADE,
  data_accredito DATE NOT NULL,
  importo NUMERIC(14,2) NOT NULL,
  note TEXT,
  inserito_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_accrediti_pres ON anticipi_sbf_accrediti(presentazione_id);
CREATE INDEX IF NOT EXISTS idx_accrediti_data ON anticipi_sbf_accrediti(data_accredito DESC);

ALTER TABLE anticipi_sbf_accrediti DISABLE ROW LEVEL SECURITY;


-- ─── TRIGGER: aggiorna importo_anticipato_totale + stato presentazione ────
-- Ogni INSERT/UPDATE/DELETE su anticipi_sbf_accrediti ricalcola la presentazione
CREATE OR REPLACE FUNCTION trg_aggiorna_presentazione()
RETURNS TRIGGER AS $$
DECLARE
  v_pres_id UUID;
  v_totale NUMERIC(14,2);
  v_richiesto NUMERIC(14,2);
  v_nuovo_stato TEXT;
  v_stato_attuale TEXT;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_pres_id := OLD.presentazione_id;
  ELSE
    v_pres_id := NEW.presentazione_id;
  END IF;

  -- Calcolo somma accrediti
  SELECT COALESCE(SUM(importo), 0) INTO v_totale
  FROM anticipi_sbf_accrediti
  WHERE presentazione_id = v_pres_id;

  -- Recupero importo richiesto e stato attuale
  SELECT importo_richiesto, stato INTO v_richiesto, v_stato_attuale
  FROM anticipi_sbf_presentazioni
  WHERE id = v_pres_id;

  -- Determino nuovo stato (ma non sovrascrivo 'estinta' o 'rifiutata' che sono manuali)
  IF v_stato_attuale IN ('estinta','rifiutata') THEN
    v_nuovo_stato := v_stato_attuale;
  ELSIF v_totale = 0 THEN
    v_nuovo_stato := 'in_delibera';
  ELSIF v_totale >= v_richiesto THEN
    v_nuovo_stato := 'anticipata';
  ELSE
    v_nuovo_stato := 'anticipata_parziale';
  END IF;

  UPDATE anticipi_sbf_presentazioni
  SET importo_anticipato_totale = v_totale,
      stato = v_nuovo_stato,
      modificato_at = NOW()
  WHERE id = v_pres_id;

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS aggiorna_pres_su_accredito ON anticipi_sbf_accrediti;
CREATE TRIGGER aggiorna_pres_su_accredito
  AFTER INSERT OR UPDATE OR DELETE ON anticipi_sbf_accrediti
  FOR EACH ROW EXECUTE FUNCTION trg_aggiorna_presentazione();


-- ─── TRIGGER: modificato_at automatico su tutte le tabelle nuove ──────────
CREATE OR REPLACE FUNCTION trg_modificato_at_generic()
RETURNS TRIGGER AS $$
BEGIN
  NEW.modificato_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS regole_modificato_at ON anticipi_sbf_regole;
CREATE TRIGGER regole_modificato_at BEFORE UPDATE ON anticipi_sbf_regole
  FOR EACH ROW EXECUTE FUNCTION trg_modificato_at_generic();

DROP TRIGGER IF EXISTS pres_modificato_at ON anticipi_sbf_presentazioni;
CREATE TRIGGER pres_modificato_at BEFORE UPDATE ON anticipi_sbf_presentazioni
  FOR EACH ROW EXECUTE FUNCTION trg_modificato_at_generic();

DROP TRIGGER IF EXISTS anticipi_ft_modificato_at ON anticipi_sbf_fatture;
CREATE TRIGGER anticipi_ft_modificato_at BEFORE UPDATE ON anticipi_sbf_fatture
  FOR EACH ROW EXECUTE FUNCTION trg_modificato_at_generic();


-- ─── VERIFICA POST-SETUP ─────────────────────────────────────────────────
-- Esegui dopo il setup per confermare RLS off su tutte
SELECT tablename, rowsecurity AS rls
FROM pg_tables
WHERE schemaname = 'public'
  AND tablename IN (
    'anticipi_sbf_regole',
    'anticipi_sbf_presentazioni',
    'anticipi_sbf_fatture',
    'anticipi_sbf_accrediti'
  )
ORDER BY tablename;
-- Atteso: 4 righe tutte con rls = false


-- ─── SEED: regola DEFAULT per ogni affidamento SBF/anticipo_fatture esistente ─
-- Crea automaticamente una regola DEFAULT (cliente_id=NULL) per ogni fido SBF
-- attivo, copiando i valori dal fido stesso. Da eseguire DOPO aver
-- compilato pct_anticipo_default + base_calcolo_default sui fidi esistenti.
INSERT INTO anticipi_sbf_regole (affidamento_id, cliente_id, percentuale_anticipo, base_calcolo, stato, note)
SELECT
  a.id,
  NULL,
  COALESCE(a.pct_anticipo_default, 100),
  COALESCE(a.base_calcolo_default, 'imponibile'),
  'attiva',
  'Regola DEFAULT auto-generata'
FROM banche_affidamenti a
WHERE a.tipo IN ('sbf','anticipo_fatture')
  AND a.stato = 'attivo'
  AND NOT EXISTS (
    SELECT 1 FROM anticipi_sbf_regole r
    WHERE r.affidamento_id = a.id AND r.cliente_id IS NULL
  );
