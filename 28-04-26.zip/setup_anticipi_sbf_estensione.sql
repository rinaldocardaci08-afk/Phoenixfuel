-- ═══════════════════════════════════════════════════════════════════════════
-- ESTENSIONE ANTICIPI SBF — modulo, storico, costi
-- Phoenix Fuel — 28/04/2026
-- Da eseguire DOPO setup_anticipi_sbf.sql
-- ═══════════════════════════════════════════════════════════════════════════

-- ─── A) SCADENZA DEFAULT A LIVELLO MODULO ────────────────────────────────
-- Aggiungo scadenza_banca_default su presentazione: vale come fallback per
-- tutte le fatture, ma ogni fattura può overridarla con la propria scadenza.
ALTER TABLE anticipi_sbf_presentazioni
  ADD COLUMN IF NOT EXISTS scadenza_banca_default DATE;

COMMENT ON COLUMN anticipi_sbf_presentazioni.scadenza_banca_default IS
  'Scadenza anticipo proposta a livello modulo. Le singole fatture possono override.';


-- ─── B) CHIUSURA AUTOMATICA MODULO QUANDO TUTTE FATTURE SONO ESTINTE ─────
-- Trigger: quando l'ultima fattura di un modulo passa a 'estinta',
-- il modulo si chiude automaticamente. Se uno torna 'anticipata' (es.
-- correzione operatore), il modulo torna 'anticipata'.
CREATE OR REPLACE FUNCTION trg_chiusura_automatica_modulo()
RETURNS TRIGGER AS $$
DECLARE
  v_pres_id UUID;
  v_n_fatture INTEGER;
  v_n_estinte INTEGER;
  v_n_escluse INTEGER;
  v_stato_corrente TEXT;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_pres_id := OLD.presentazione_id;
  ELSE
    v_pres_id := NEW.presentazione_id;
  END IF;

  -- Conta fatture del modulo
  SELECT COUNT(*),
         COUNT(*) FILTER (WHERE stato = 'estinta'),
         COUNT(*) FILTER (WHERE stato = 'esclusa')
  INTO v_n_fatture, v_n_estinte, v_n_escluse
  FROM anticipi_sbf_fatture
  WHERE presentazione_id = v_pres_id;

  -- Recupera stato modulo attuale
  SELECT stato INTO v_stato_corrente
  FROM anticipi_sbf_presentazioni
  WHERE id = v_pres_id;

  -- Non tocco moduli rifiutati (gestione manuale)
  IF v_stato_corrente = 'rifiutata' THEN
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
  END IF;

  -- Se tutte le fatture (escluse quelle 'esclusa') sono estinte → modulo estinto
  IF v_n_fatture > 0 AND (v_n_estinte + v_n_escluse) = v_n_fatture AND v_n_estinte > 0 THEN
    UPDATE anticipi_sbf_presentazioni
    SET stato = 'estinta', modificato_at = NOW()
    WHERE id = v_pres_id;
  -- Se invece una è tornata indietro (estinta → anticipata) e il modulo era estinto, riapri
  ELSIF v_stato_corrente = 'estinta' AND v_n_estinte < v_n_fatture - v_n_escluse THEN
    UPDATE anticipi_sbf_presentazioni
    SET stato = CASE
      WHEN importo_anticipato_totale = 0 THEN 'in_delibera'
      WHEN importo_anticipato_totale >= importo_richiesto THEN 'anticipata'
      ELSE 'anticipata_parziale'
    END,
    modificato_at = NOW()
    WHERE id = v_pres_id;
  END IF;

  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS chiusura_modulo ON anticipi_sbf_fatture;
CREATE TRIGGER chiusura_modulo
  AFTER INSERT OR UPDATE OF stato OR DELETE ON anticipi_sbf_fatture
  FOR EACH ROW EXECUTE FUNCTION trg_chiusura_automatica_modulo();


-- ─── C) COSTI ANTICIPO PER ISTITUTO ──────────────────────────────────────
-- Tracciamento costi: preventivati (calcolati da tasso fido) vs reali
-- (inseriti dall'operatore da estratto conto). Permette analytics multi-banca.

CREATE TABLE IF NOT EXISTS anticipi_sbf_costi (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  presentazione_id UUID REFERENCES anticipi_sbf_presentazioni(id) ON DELETE CASCADE,
  affidamento_id UUID REFERENCES banche_affidamenti(id) ON DELETE RESTRICT,
  data_competenza DATE NOT NULL,           -- data del costo (da estratto conto)
  tipo_costo TEXT NOT NULL CHECK (tipo_costo IN (
    'interessi',          -- interessi sull'anticipo
    'commissioni',        -- commissioni di presentazione
    'spese_incasso',      -- spese su singola riba/incasso
    'imposta_bollo',      -- bolli su distinta
    'altro'
  )),
  importo_preventivato NUMERIC(14,2) DEFAULT 0,  -- calcolato da tasso fido
  importo_reale NUMERIC(14,2),                   -- da estratto conto (può essere NULL finché non lo inserisci)
  fonte TEXT CHECK (fonte IN ('preventivo','estratto_conto','manuale')),
  data_addebito DATE,                            -- quando la banca ha addebitato (da estratto)
  riferimento TEXT,                              -- numero distinta/riferimento banca
  note TEXT,
  inserito_at TIMESTAMP DEFAULT NOW(),
  modificato_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_costi_presentazione ON anticipi_sbf_costi(presentazione_id);
CREATE INDEX IF NOT EXISTS idx_costi_affidamento ON anticipi_sbf_costi(affidamento_id);
CREATE INDEX IF NOT EXISTS idx_costi_data ON anticipi_sbf_costi(data_competenza DESC);
CREATE INDEX IF NOT EXISTS idx_costi_tipo ON anticipi_sbf_costi(tipo_costo);

ALTER TABLE anticipi_sbf_costi DISABLE ROW LEVEL SECURITY;

DROP TRIGGER IF EXISTS costi_modificato_at ON anticipi_sbf_costi;
CREATE TRIGGER costi_modificato_at BEFORE UPDATE ON anticipi_sbf_costi
  FOR EACH ROW EXECUTE FUNCTION trg_modificato_at_generic();


-- ─── D) VISTA ANALITICA: costo per istituto/anno (per future analytics) ───
-- Una vista pronta che aggrega per banca + anno per dashboard futuri.
-- Calcola: volume anticipato, costo preventivato, costo reale, costo per €1.000
CREATE OR REPLACE VIEW v_anticipi_costi_per_istituto AS
SELECT
  i.id AS istituto_id,
  i.nome AS istituto_nome,
  EXTRACT(YEAR FROM p.data_presentazione)::INTEGER AS anno,
  COUNT(DISTINCT p.id) AS n_moduli,
  COUNT(DISTINCT f.id) AS n_fatture,
  COALESCE(SUM(p.importo_anticipato_totale), 0) AS volume_anticipato,
  COALESCE(SUM(c.importo_preventivato), 0) AS costo_preventivato,
  COALESCE(SUM(c.importo_reale), 0) AS costo_reale,
  CASE
    WHEN COALESCE(SUM(p.importo_anticipato_totale), 0) > 0
    THEN ROUND(COALESCE(SUM(c.importo_reale), 0) / SUM(p.importo_anticipato_totale) * 1000, 2)
    ELSE NULL
  END AS costo_per_mille_reale,
  CASE
    WHEN COALESCE(SUM(p.importo_anticipato_totale), 0) > 0
    THEN ROUND(COALESCE(SUM(c.importo_preventivato), 0) / SUM(p.importo_anticipato_totale) * 1000, 2)
    ELSE NULL
  END AS costo_per_mille_preventivato,
  COALESCE(SUM(c.importo_reale), 0) - COALESCE(SUM(c.importo_preventivato), 0) AS delta_reale_vs_preventivato
FROM banche_istituti i
JOIN banche_affidamenti a ON a.istituto_id = i.id AND a.tipo IN ('sbf','anticipo_fatture')
JOIN anticipi_sbf_presentazioni p ON p.affidamento_id = a.id
LEFT JOIN anticipi_sbf_fatture f ON f.presentazione_id = p.id
LEFT JOIN anticipi_sbf_costi c ON c.presentazione_id = p.id
WHERE p.stato != 'rifiutata'
GROUP BY i.id, i.nome, EXTRACT(YEAR FROM p.data_presentazione)
ORDER BY anno DESC, i.nome;


-- ─── E) VERIFICA ─────────────────────────────────────────────────────────
SELECT tablename, rowsecurity AS rls
FROM pg_tables
WHERE schemaname = 'public'
  AND tablename IN ('anticipi_sbf_costi')
ORDER BY tablename;
-- Atteso: 1 riga con rls = false

SELECT 'Trigger chiusura_modulo' AS check, COUNT(*) AS presente
FROM information_schema.triggers WHERE trigger_name = 'chiusura_modulo';
-- Atteso: presente = 1

SELECT 'Vista analitica' AS check, COUNT(*) AS presente
FROM information_schema.views WHERE table_name = 'v_anticipi_costi_per_istituto';
-- Atteso: presente = 1
